﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



// classe que ira delegar funcao para outra classe
public delegate float FuncoesGraficos(float x, float t);
