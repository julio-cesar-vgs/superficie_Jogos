﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Superficies : MonoBehaviour
{

    // Elementos de controle da animação
    public Transform ptCubo;

    // Controle de resolução do gráfico
    [Range(10, 100)]
    public int resolucao = 30;

    // Gerenciamento de pontos
    Transform[] pontos;


    //public int resolucao = 10;

    private void Awake()
    {

        float passo = 2f / resolucao;
        Vector3 escala = Vector3.one * passo;
        Vector3 posicao;

        posicao.y = 0f;
        posicao.z = 0f;

        pontos = new Transform[resolucao];

        for (int c = 0; c < resolucao; c++)
        {
            Transform ponto = Instantiate(ptCubo);
            posicao.x = ((c + 0.5f) * passo - 1f);
            //posicao.y = posicao.x * posicao.x * posicao.x;
            //posicao.y = posicao.x * posicao.x;
            ponto.localPosition = posicao;
            ponto.localScale = escala;
            ponto.SetParent(transform, false);
            pontos[c] = ponto;
        }

    }

    private void Update()
    {
        for (int c = 0; c < pontos.Length; c++)
        {
            Transform ponto = pontos[c];
            Vector3 posicao = ponto.localPosition;
            //posicao.y = posicao.x * posicao.x * posicao.x;
            posicao.y = Mathf.Sin(Mathf.PI * posicao.x + Time.time);
            ponto.localPosition = posicao;
        }
    }


}
