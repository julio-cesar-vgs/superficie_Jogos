﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Superficies : MonoBehaviour
{

    // Elementos de controle da animação
    public Transform ptCubo;

    // Controle de resolução do gráfico
    [Range(10, 100)]
    public int resolucao = 30;

    //Escolha da funcao a renderizar
    //[Range(0, 1)]
    //public int Funcao = 0;

    public NomeFuncoes fc;

    // Gerenciamento de pontos
    Transform[] pontos;


    //public int resolucao = 10;

    private void Awake()
    {

        float passo = 2f / resolucao;
        Vector3 escala = Vector3.one * passo;
        Vector3 posicao;

        posicao.y = 0f;
        posicao.z = 0f;

        pontos = new Transform[resolucao];

        for (int c = 0, x = 0, z=0; c < resolucao; c++, x++)
        {

            if (x == resolucao)
            {
                x = 0;
                z += 1;
            }
            Transform ponto = Instantiate(ptCubo);
            posicao.x = ((x + 0.5f) * passo - 1f);
            posicao.z = ((z + 0.5f) * passo - 1f);
            //posicao.y = posicao.x * posicao.x * posicao.x;
            //posicao.y = posicao.x * posicao.x;
            ponto.localPosition = posicao;
            ponto.localScale = escala;
            ponto.SetParent(transform, false);
            pontos[c] = ponto;
        }

    }

    private void Update()
    {

        float t = Time.time;


        //if(Funcao == 0)
        //{
        //    f = Seno;
        //}
        //  else
        //{
        //f = MultSeno;
        //}

        FuncoesGraficos[] funcoes = { Seno, MultSeno, Seno2D };
        FuncoesGraficos f = funcoes[(int)fc];


        for (int c = 0; c < pontos.Length; c++)
        {
            Transform ponto = pontos[c];
            Vector3 posicao = ponto.localPosition;
            //posicao.y = posicao.x * posicao.x * posicao.x;
            //posicao.y = Mathf.Sin(Mathf.PI * posicao.x + Time.time);
            //posicao.y = Seno(posicao.x, t);



            /** 
             * bloco apagado apos o uso do delegate
             * if(Funcao == 0)
             {
                 posicao.y = Seno(posicao.x, t);
             }else
             {
                 posicao.y = MultSeno(posicao.x, t);
             }
           */
            posicao.y = f(posicao.x, posicao.z, t);
            ponto.localPosition = posicao;
        }
    }


    float Seno(float x, float z, float t)
    {
        return Mathf.Sin(Mathf.PI * (x + t));
    }

    static float MultSeno(float x, float z, float t)
    {
        float y = Mathf.Sin(Mathf.PI * (x + t));
        y += Mathf.Sin(2f * Mathf.PI * (x + t)) / 2f;
        y *= 2f / 3f;
        return y;
    }

    static float Seno2D(float x, float z, float t)
    {
        return Mathf.Sin(Mathf.PI * (x + z + t));
    }


}
